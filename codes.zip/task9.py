# write a python program to display a user entered name followed by Good Afternoon using input() function and fstring.
name = input("Enter your name: ")
print(f"Good Afternoon {name}")